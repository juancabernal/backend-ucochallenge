package co.edu.uco.parametersservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ParametersServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
