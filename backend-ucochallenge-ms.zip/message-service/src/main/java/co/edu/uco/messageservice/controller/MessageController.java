package co.edu.uco.messageservice.controller;

import java.util.Map;

import org.springframework.http.CacheControl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import co.edu.uco.messageservice.catalog.Message;
import co.edu.uco.messageservice.catalog.MessageCatalog;

@RestController
@RequestMapping("/api/v1/messages")
public class MessageController {

        @GetMapping("/{key}")
        public ResponseEntity<Message> getMessage(@PathVariable String key,
                        @RequestParam Map<String, String> parameters) {

                final Message value = MessageCatalog.getMessageValue(key, parameters);
                if (value == null) {
                        return ResponseEntity.status(HttpStatus.NOT_FOUND)
                                        .cacheControl(CacheControl.noStore().mustRevalidate())
                                        .header("Pragma", "no-cache")
                                        .header("Expires", "0")
                                        .build();
                }

                return ResponseEntity.ok()
                                .cacheControl(CacheControl.noStore().mustRevalidate())
                                .header("Pragma", "no-cache")
                                .header("Expires", "0")
                                .body(new Message(value.getKey(), value.getValue()));

        }

        @PutMapping("/{key}")
        public ResponseEntity<Message> modifyMessage(@PathVariable String key, @RequestBody Message value) {

                value.setKey(key);
                MessageCatalog.synchronizeMessageValue(value);
                return ResponseEntity.ok()
                                .cacheControl(CacheControl.noStore().mustRevalidate())
                                .header("Pragma", "no-cache")
                                .header("Expires", "0")
                                .body(new Message(value.getKey(), value.getValue()));

        }

}
