package co.edu.uco.ucochallenge.secondary.ports.service;

public interface ParameterServicePort {

    String getParameter(String key);
}
