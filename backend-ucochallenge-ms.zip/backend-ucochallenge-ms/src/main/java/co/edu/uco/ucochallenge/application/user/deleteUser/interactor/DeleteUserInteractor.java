package co.edu.uco.ucochallenge.application.user.deleteUser.interactor;

import java.util.UUID;

import co.edu.uco.ucochallenge.application.Void;
import co.edu.uco.ucochallenge.application.interactor.Interactor;

public interface DeleteUserInteractor extends Interactor<UUID, Void> {
}
