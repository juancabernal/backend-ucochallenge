package co.edu.uco.ucochallenge.application.user.registerUser.rules.impl;

public class ExecuteDomainRules {
}
