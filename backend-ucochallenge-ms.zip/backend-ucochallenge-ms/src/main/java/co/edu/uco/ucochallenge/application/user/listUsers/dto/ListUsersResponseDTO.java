package co.edu.uco.ucochallenge.application.user.listUsers.dto;

import java.util.List;

public record ListUsersResponseDTO(List<ListUsersOutputDTO> users) {
}
