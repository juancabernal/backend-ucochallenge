package co.edu.uco.ucochallenge.application.user.deleteUser.usecase;

import java.util.UUID;

import co.edu.uco.ucochallenge.application.Void;
import co.edu.uco.ucochallenge.application.usecase.UseCase;

public interface DeleteUserUseCase extends UseCase<UUID, Void> {
}
