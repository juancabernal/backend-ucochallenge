package co.edu.uco.ucochallenge.domain.user.rules.impl.format;

public class IdNumberFormatRule {
}
