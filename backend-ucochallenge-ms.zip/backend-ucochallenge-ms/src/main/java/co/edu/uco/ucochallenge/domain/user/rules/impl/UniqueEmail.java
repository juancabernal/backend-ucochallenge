package co.edu.uco.ucochallenge.domain.user.rules.impl;

public class UniqueEmail {
}
