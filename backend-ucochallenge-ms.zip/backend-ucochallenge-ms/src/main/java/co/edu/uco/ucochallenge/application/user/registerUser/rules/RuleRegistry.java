package co.edu.uco.ucochallenge.application.user.registerUser.rules;

public class RuleRegistry {
}
